import { Component } from '@angular/core';

@Component({
    template: '<quiz></quiz><quizzes></quizzes>'
})
export class HomeComponent {

}
